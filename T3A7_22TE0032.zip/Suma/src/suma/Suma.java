package suma;

import java.util.Scanner;

public class Suma {

    public static void main(String[] args) {
       //ejercicio1();
       //ejercicio2();
       //ejercicio3();
       ejercicio4();
    }
    
    //Solicitar una cantidad determinada de n�meros secuenciales y calcular la suma total de estos.
    public static void ejercicio1(){
        Scanner scanner = new Scanner (System.in);
        System.out.println("SUMA DE N�MEROS SECUENCIALES");
        
        System.out.println("Cuantos n�meros quieres sumar: ");
        int limite = scanner.nextInt();
        System.out.println("Desde que n�mero deseas iniciar: ");
        int inicio = scanner.nextInt();
        System.out.println("Incremento: ");
        int incremento = scanner.nextInt();
        
        int sumatol= 0;
        
        int numsuma = inicio + limite;
        System.out.println("Inicio: " + inicio 
                + "\nLimite: " + numsuma 
                + "\nCantidad de n�meros a sumar " + limite);
        
                
        for (int numero = inicio; numero <= numsuma; numero += incremento){
            sumatol+= numero;
        System.out.println("Suma de los n�meros " + numero);
            System.out.println("La suma es: " + sumatol);
        
        }
    } 
    
   //Pedir los primero 10 n�meros impares y calcular el producto.
    public static void ejercicio2(){
        Scanner scanner = new Scanner (System.in);
        System.out.println("SUMA DE N�MEROS IMPARES");
        
        System.out.println("Se sumaran los primeros 10 n�meros");
        System.out.println("Desde que n�mero deseas iniciar que sea impar");
        int inicio = scanner.nextInt();
       
        int sumatol= 0;
        
        int numsuma = inicio * 9;
        System.out.println("Inicio: " + inicio 
                + "\nLimite: " + numsuma  );
        
                
        for (int i = inicio; i <= numsuma; i +=2){
            sumatol+= i;
        System.out.println("Suma de los n�meros " + i);
            System.out.println("La suma es: " + sumatol);
        }
    }
    //Registrar una cantidad determinada de trabajadores: nombre y salario. Luego, calcular el promedio de los salarios.
    public static void ejercicio3(){
        Scanner scanner = new Scanner (System.in);
        System.out.println("PROMEDIO DE SALARIOS");
        
        int limite;
       double promedioSalario;
       
       System.out.println("Cuantos trabajadores deseas ingresar");
            limite = scanner.nextInt();
            
            int sumatol= 0;
            float suma=0;
       for(int i = 1; i<=limite; i++){
          sumatol+= i;
           
            System.out.print("Nombre: "  );
           String nombre = scanner.next();
            
            System.out.println("Ingrese su salario:");
            float salario = scanner.nextFloat();
            suma =  suma+salario;
           
            System.out.println("La suma es: " + suma);
            
        
           }   
      
              
       System.out.println("Cantidad de trabajadores: " + limite 
               + "\nPromedio Salario: " + suma/limite );
        
    }
    //Dadas las edades y alturas de 5 alumnos, mostrar la edad y la 
        //estatura media, la cantidad de alumnos mayores de 18 a�os, y la 
        //cantidad de alumnos que miden m�s de 1.75.
    public static void ejercicio4(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("ESTAURAS Y EDADES");
        
        int edad, limite;
        int mayorDe18 = 0;
        int mayorDe175 = 0;
        float estatura, sumaEstatura;
        double promedioEstatura;
        
        float suma=0;
        System.out.println("Cuantos alumnos desea ingresar");
            limite = scanner.nextInt();
        
        for(int i = 0; i<limite; i++){
            System.out.print("Edad: ");
            edad = scanner.nextInt();
            
           if (edad>18){
               mayorDe18++;
           }         
            
            System.out.println("Estatura: ");
           estatura = scanner.nextFloat();
            if (estatura>mayorDe175){
                mayorDe175++;
            }
          estatura += estatura;
           promedioEstatura = estatura/limite;
           suma = suma+estatura;
           
            System.out.println("La suma es: " + suma);
        }
        System.out.println("Mayor de 18 a�os: " + mayorDe18);
        System.out.println("Mayor de 1.75: " + mayorDe175);
        System.out.println("Estatura media: " + suma/limite);
    }
    
}
